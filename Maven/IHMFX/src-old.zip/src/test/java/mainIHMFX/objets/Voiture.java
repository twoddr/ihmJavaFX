package mainIHMFX.objets;

import general.ObjetCSA;

public class Voiture extends ObjetCSA {
    public Voiture() {
        super("Voiture", "idvoiture", "marque");
        reinitialiser();
    }

    @Override
    public ObjetCSA getParent() {
        return null;
    }

    @Override
    public void setParent(ObjetCSA objetCSA) {

    }

    @Override
    public ObjetCSA getObjetFromType(String s) {
        return new GenerateurObjets().getObjetFromType(s);
    }

    @Override
    public void reinitialiser() {
        setPublicName("Voiture");
        setNom("");
        initialiser("modelevoiture", "");
        initialiser("anneevoiture", 1980);
        add_variable_a_afficher("marque");
        add_variable_a_afficher("modelevoiture");
        add_variable_a_afficher("anneevoiture");
        add_nom_public("marque", "Marque");
        add_nom_public("anneevoiture", "Année");
        add_nom_public("modelevoiture", "Modèle");
    }

    public int getAnnee() {
        return (int) getSimpleData("anneevoiture");
    }

    public void setAnnee(int annee) {
        inserer_valeur("anneevoiture", annee);
    }

    public String getMarque() {
        return String.valueOf(getSimpleData("marque"));
    }

    public void setMarque(String marque) {
        inserer_valeur("marque", marque);
    }
}
