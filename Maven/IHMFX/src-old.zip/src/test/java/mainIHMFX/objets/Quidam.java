package mainIHMFX.objets;

import general.ObjetCSA;

import java.time.LocalDate;

public class Quidam extends ObjetCSA {
    public Quidam() {
        super("Quidam", "idQuidam", "nomquidam");
        reinitialiser();
    }

    @Override
    public ObjetCSA getParent() {
        return null;
    }

    @Override
    public void setParent(ObjetCSA objetCSA) {

    }

    @Override
    public ObjetCSA getObjetFromType(String s) {
        return new GenerateurObjets().getObjetFromType(s);
    }

    @Override
    public void reinitialiser() {
        setPublicName("Client ou patient");
        initialiser("prenomquidam", "");
        initialiser("sexequidam", "Indéterminé");
        initialiser("datenaissancequidam", LocalDate.now().minusYears(18));
        initialiser("hospitalise", false);

        setFK("fkcontact", "Contact");
        setFK("fkmedecin", "Medecin");

        initialiser_liste("Voiture");
        initialiser_liste("Prestation");
        initialiser_liste("Article");

        add_nom_public("fkcontact", "Coordonnées de contact");
        add_nom_public("nomquidam", "Nom");
        add_nom_public("prenomquidam", "Prénom");
        add_nom_public("sexequidam", "Sexe");
        add_nom_public("datenaissancequidam", "Date de naissance");
        add_nom_public("hospitalise", "Hospitalisé ?");
        add_nom_public("fkmedecin", "Médecin traitant");
        add_nom_public("Voiture", "Liste des voitures");
    }
}
