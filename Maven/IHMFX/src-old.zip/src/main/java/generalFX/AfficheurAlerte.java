package generalFX;

import javafx.application.Platform;
import javafx.scene.control.Alert;

public class AfficheurAlerte {

    public void afficher(String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert fenetre = new Alert(type);
            fenetre.getDialogPane().setPrefWidth(Math.max(600, message.length() * 8));
            fenetre.setContentText(message);
            fenetre.showAndWait();
        });
    }
}
