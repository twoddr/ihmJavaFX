package generalFX;

import javafx.scene.paint.Color;

public class RGBConverter {

    public Integer convert_color_2_rgb(Color color) {
//        int opacite = ((int) (color.getOpacity() * 255)) << 24;
//        int rouge = ((int) (color.getRed() * 255)) << 16;
//        int vert = ((int) (color.getGreen() * 255)) << 8;
//        int bleu = ((int) (color.getBlue() * 255));
//
//        int couleurInt = rouge + vert + bleu + opacite;
        /*System.out.println("\nDEBUG : Couleur " + color + " qui est découpée en (0x" + opacite
                + String.format("%03d", rouge) +
                String.format("%03d", vert) +
                String.format("%03d", bleu) + ") converti en "
                + couleurInt);*/
        int rouge = ((int) (color.getRed() * 255)) << 24;
        int vert = ((int) (color.getGreen() * 255)) << 16;
        int bleu = ((int) (color.getBlue() * 255)) << 8;
        int opacite = ((int) (color.getOpacity() * 255));

        return rouge + vert + bleu + opacite;
        //return couleurInt;
    }

    public Color convert_rgb_2_color(int couleur) {
        int red = (couleur >> 24) & 0xFF;
        int green = (couleur >> 16) & 0xFF;
        int blue = (couleur >> 8) & 0xFF;
        int opacity = couleur & 0xFF;

        /*System.out.println("\nDEBUG : Couleur (" + couleur + ") convertie en Color : 0x" +
                String.format("%03d", (int) opacity)
                + String.format("%03d", (int) red)
                + String.format("%03d", (int) green)
                + String.format("%03d", (int) blue));*/

        return Color.color(red / 255f,
                green / 255f,
                blue / 255f,
                opacity / 255f);
    }

}
