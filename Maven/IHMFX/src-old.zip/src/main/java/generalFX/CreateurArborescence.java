package generalFX;

import general.ObjetCSA;
import javafx.scene.control.TreeItem;

import java.util.ArrayList;
import java.util.function.Predicate;

public class CreateurArborescence {


    public static ArrayList<TreeItem<ObjetIHM>> creer_arborescence(ArrayList<? extends ObjetCSA> objetDis,
                                                                   ObjetCSA parent) {
        ArrayList<TreeItem<ObjetIHM>> treeItemsParents = new ArrayList<>();
        if (objetDis.isEmpty()) {
            return treeItemsParents;
        }
        Predicate<ObjetCSA> predicat = new Predicate<ObjetCSA>() {
            @Override
            public boolean test(ObjetCSA objetDi) {
                if (parent == null || parent.getId() == 0) {
                    return objetDi.getIdParent() == 0;
                }
                return parent.getId() == objetDi.getIdParent() &&
                        parent.getType().equals(objetDi.getParent().getType());
            }
        };
        splitList(objetDis, predicat, treeItemsParents);

        for (TreeItem<ObjetIHM> treeItemParent : treeItemsParents) {
            if (objetDis.isEmpty()) break;
            if (treeItemParent.getValue() != null) {
                ObjetIHM noeudIHM = treeItemParent.getValue();
                ArrayList<TreeItem<ObjetIHM>> petits_enfants = creer_arborescence(objetDis, noeudIHM.getObjetCSA());
                treeItemParent.getChildren().setAll(petits_enfants);
                boolean nonvide = !petits_enfants.isEmpty();
                treeItemParent.setExpanded(nonvide);
            }
        }

        return treeItemsParents;
    }

    private static void splitList(ArrayList<? extends ObjetCSA> objetDis, Predicate<ObjetCSA> postulat, ArrayList<TreeItem<ObjetIHM>> treeItemParents) {
        ArrayList<ObjetCSA> utilises = new ArrayList<>();
        for (ObjetCSA objetDi : objetDis) {
            //System.out.println("***\nDEBUG : Test de postulat entre " + objetDi + " et son parent + haut >>> ");
            if (postulat.test(objetDi)) {
                //System.out.println("VRAI");
                treeItemParents.add(new TreeItem<>(new ObjetIHM(objetDi)));
                utilises.add(objetDi);
            }
            //System.out.println("FAUX");
        }
        objetDis.removeAll(utilises);
    }

    /*private static ArrayList<TreeItem<ObjetIHM>> trouver_parents(ArrayList<? extends ObjetCSA> objetDis) {
        ArrayList<TreeItem<ObjetIHM>> sortie = new ArrayList<>();
        for (ObjetCSA objetDi : objetDis) {
            if (objetDi.getIdParent() == 0) {
                sortie.add(new TreeItem<>(new ObjetIHM(objetDi)));
            }
        }
        return sortie;
    }*/

}
