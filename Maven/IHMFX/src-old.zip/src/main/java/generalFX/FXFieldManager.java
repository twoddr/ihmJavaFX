/**
 *
 */

package generalFX;

import controlsFX.ComboFiltrableController;
import general.ObjetDi;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

/**
 * @author dtw
 */
public class FXFieldManager extends HashMap<Node, generalFX.Capsule> implements Serializable {

    /**
     * un textArea permettant de communiquer en sortie
     */
    private TextArea logArea;

    // *** constructeurs
    public FXFieldManager() {

    }

    public FXFieldManager(ArrayList<Node> alx) {
        setListeComposants(alx);
    }


    /**
     * Permet de charger les données vers les champs correspondants
     */
    public void charger_variables_vers_champs() {
        for (Entry<Node, generalFX.Capsule> paire : entrySet()) {
            Node noeud = paire.getKey();
            generalFX.Capsule capsule = paire.getValue();
            if (noeud != null) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        if (capsule.getVariable() instanceof ObjetDi) {
                            if (noeud instanceof ComboBox) {
                                ComboBox<Object> combo = (ComboBox) noeud;
                                combo.getSelectionModel().select(capsule.getVariable());

                            } else if (noeud instanceof ComboFiltrableController) {
                                ComboFiltrableController combof = (ComboFiltrableController) noeud;
                                combof.select(capsule.getVariable());
                                combof.setTexte(capsule.getVariable().toString());
                            } else if (noeud instanceof ListView) {

                                ((ListView) noeud).getSelectionModel().select(capsule.getVariable());

                            } else if (noeud instanceof TextField) {

                                ((TextField) noeud).setText(capsule.getVariable().toString());

                            } else if (noeud instanceof Label) {

                                ((Label) noeud).setText(capsule.getVariable().toString());

                            } else if (noeud instanceof CheckBox) {
                                if (capsule.getType().equals(Boolean.class)) {
                                    ((CheckBox) noeud).setSelected((Boolean) capsule.getVariable());
                                }
                            } else if (noeud instanceof RadioButton) {
                                if (capsule.getVariable() instanceof Boolean) {
                                    ((RadioButton) noeud).setSelected((Boolean) capsule.getVariable());
                                }
                            } else {
                                String s = "FXFieldManager : ne peut insérer un ElementBD dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        } else if (capsule.getVariable() instanceof Integer) {
                            if (noeud instanceof TextField) {
                                ((TextField) noeud).setText("" + capsule.getVariable());
                            } else if (noeud instanceof ComboBox) {
                                Boolean pasTrouve = true;
                                for (Object elt : ((ComboBox) noeud).getItems()) {
                                    if (elt instanceof ObjetDi) {
                                        if (((ObjetDi) elt).getId() == (Integer) capsule.getVariable()) {
                                            pasTrouve = false;
                                            ((ComboBox) noeud).getSelectionModel().select(elt);
                                            break;
                                        }
                                    }
                                }
                                if (pasTrouve) {
                                    ((ComboBox) noeud).getSelectionModel()
                                            .select(capsule.getVariable());
                                }
                            } else if (noeud instanceof ComboFiltrableController) {
                                Boolean pasTrouve = true;
                                for (Object elt : ((ComboFiltrableController) noeud).getListeAffichee()) {
                                    if (elt instanceof ObjetDi) {
                                        if (((ObjetDi) elt).getId() == (Integer) capsule.getVariable()) {
                                            pasTrouve = false;
                                            ComboFiltrableController combof = (ComboFiltrableController) noeud;
                                            combof.select(elt);
                                            combof.setTexte(elt + "");
                                            break;
                                        }
                                    }
                                }
                                if (pasTrouve) {
                                    ComboFiltrableController combof = (ComboFiltrableController) noeud;
                                    combof.select(capsule.getVariable());
                                    combof.setTexte(combof.getSelection() + "");
                                }
                            } else if (noeud instanceof Label) {
                                ((Label) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof TextArea) {
                                ((TextArea) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof ListView) {
                                Boolean pasTrouve = true;
                                for (Object elt : ((ListView<Object>) noeud).getItems()) {
                                    if (elt instanceof ObjetDi) {
                                        if (((ObjetDi) elt).getId() == (Integer) capsule.getVariable()) {
                                            pasTrouve = false;
                                            ((ListView<Object>) noeud).getSelectionModel().select(elt);
                                            break;
                                        }
                                    }
                                }
                                if (pasTrouve) {
                                    ((ListView<Object>) noeud).getSelectionModel()
                                            .select(capsule.getVariable());
                                }
                            } else {
                                String s = "FXFieldManager : ne peut insérer un Integer dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        } else if (capsule.getVariable() instanceof String) {
                            if (noeud instanceof TextField) {
                                ((TextField) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof ComboBox) {
                                ((ComboBox) noeud).getSelectionModel()
                                        .select(capsule.getVariable() + "");
                            } else if (noeud instanceof ComboFiltrableController) {
                                ComboFiltrableController combof = (ComboFiltrableController) noeud;
                                combof.select(capsule.getVariable() + "");
                                combof.setTexte(capsule.getVariable() + "");
                            } else if (noeud instanceof ListView) {
                                ((ListView) noeud).getSelectionModel()
                                        .select(capsule.getVariable() + "");
                            } else if (noeud instanceof Button) {
                                ((Button) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof Label) {
                                ((Label) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof TextArea) {
                                ((TextArea) noeud).setText(capsule.getVariable() + "");
                            } else {
                                String s = "FXFieldManager : ne peut insérer un String dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        } else if (capsule.getVariable() instanceof Float) {
                            if (noeud instanceof TextField) {
                                ((TextField) noeud).setText("" + capsule.getVariable());
                            } else if (noeud instanceof Label) {
                                ((Label) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof TextArea) {
                                ((TextArea) noeud).setText(capsule.getVariable() + "");
                            } else {
                                String s = "FXFieldManager : ne peut insérer un Float dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        } else if (capsule.getVariable() instanceof Boolean) {
                            if (noeud instanceof CheckBox) {
                                ((CheckBox) noeud).setSelected((Boolean) capsule.getVariable());
                            } else if (noeud instanceof RadioButton) {
                                ((RadioButton) noeud).setSelected((Boolean) capsule.getVariable());
                            } else if (noeud instanceof TextField) {
                                ((TextField) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof Label) {
                                ((Label) noeud).setText(capsule.getVariable() + "");
                            } else if (noeud instanceof TextArea) {
                                ((TextArea) noeud).setText(capsule.getVariable() + "");
                            } else {
                                String s = "FXFieldManager : ne peut insérer un Booléen dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        } else if (capsule.getVariable() instanceof ArrayList) {
                            if (noeud instanceof ComboBox) {
                                ComboBox box = (ComboBox) noeud;
                                Object tmp = box.getSelectionModel().getSelectedItem();
                                box.getItems().clear();
                                box.getItems().addAll((ArrayList) capsule.getVariable());
                                if (tmp != null && box.getItems().contains(tmp)) {
                                    box.getSelectionModel().select(tmp);
                                }
                            } else if (noeud instanceof ComboFiltrableController) {
                                ComboFiltrableController box = (ComboFiltrableController) noeud;
                                Object tmp = box.getSelection();
                                box.setListe((ArrayList) capsule.getVariable());
                                box.setTexte("");
                                if (tmp != null && box.getListeAffichee().contains(tmp)) {
                                    box.select(tmp);
                                    box.setTexte(box.getSelection().toString());
                                }
                            } else if (noeud instanceof ListView) {
                                ListView liste = (ListView) noeud;
                                liste.getItems().addAll((ArrayList) capsule.getVariable());
                            } else if (noeud instanceof Button) {
                                ((Button) noeud).setText(((ArrayList) capsule.getVariable()).size() + "");
                            } else {
                                String s = "FXFieldManager : ne peut insérer une ArrayList dans un " +
                                        noeud.getClass().getSimpleName();
                                System.err.println(s);
                                ecrire_dans_log(s);
                            }
                        }
                    }
                });
            }
        }


    }

    private void ecrire_dans_log(String s) {
        if (logArea != null) {
            Calendar now = Calendar.getInstance();
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    logArea.appendText("\n" +
                            LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm")) + "\n"
                            + s);
                }
            });

        }
    }

    /**
     * Permet de charger les données qui sont dans le champ vers la variable
     */
    public void charger_champs_vers_variables() {
        for (Entry<Node, generalFX.Capsule> paire : entrySet()) {
            Node composant = paire.getKey();
            generalFX.Capsule capsule = paire.getValue();
            if (composant instanceof ComboBox) {
                ComboBox combo = (ComboBox) composant;
                if (capsule.getVariable() instanceof Integer) {
                    if (combo.getSelectionModel().getSelectedItem() instanceof Integer) {
                        capsule.setVariable(combo.getSelectionModel().getSelectedItem());
                    } else {
                        capsule.setVariable(combo.getSelectionModel().getSelectedIndex());
                    }
                } else if (capsule.getVariable() instanceof ObjetDi) {
                    try {
                        ObjetDi objet = (ObjetDi) combo.getSelectionModel().getSelectedItem();
                        if (objet.getClass().equals(capsule.getType())) {
                            ((ObjetDi) capsule.getVariable()).setId(objet.getId());
                            ((ObjetDi) capsule.getVariable()).setNom(objet.getNom());
                        } else {
                            String s = "FXFieldManager : Combo objet sélectionné : " + objet.getClass().getSimpleName()
                                    + "\n ne peut être associé à un : " + capsule.getVariable().getClass()
                                    .getSimpleName();
                            System.err.println(s);
                            ecrire_dans_log(s);
                        }
                    } catch (Exception ignored) {
                    }
                } else if (capsule.getVariable() instanceof String) {
                    capsule.setVariable(combo.getSelectionModel().getSelectedItem().toString());
                } else {
                    Object objet = combo.getSelectionModel().getSelectedItem();
                    try {
                        capsule.setVariable(objet);
                    } catch (Exception e) {
                        System.err.println("FXfieldMan : l'objet extrait du combo de type " + objet.getClass().getSimpleName()
                                + " ne peut être inséré dans la variable correspondante !");
                    }
                }

            } else if (composant instanceof ComboFiltrableController) {
                ComboFiltrableController combo = (ComboFiltrableController) composant;
                if (capsule.getVariable() instanceof Integer) {
                    capsule.setVariable(combo.getIndiceSelectionne());
                } else if (capsule.getVariable() instanceof ObjetDi) {
                    try {
                        ObjetDi objet = (ObjetDi) combo.getSelection();
                        if (objet.getClass().equals(capsule.getType())) {
                            ((ObjetDi) capsule.getVariable()).setId(objet.getId());
                            ((ObjetDi) capsule.getVariable()).setNom(objet.getNom());
                        } else {
                            String s = "FXFieldManager : Combo objet sélectionné : " + objet.getClass().getSimpleName()
                                    + "\n ne peut être associé à un : " + capsule.getVariable().getClass()
                                    .getSimpleName();
                            System.err.println(s);
                            ecrire_dans_log(s);
                        }
                    } catch (Exception ignored) {
                    }
                } else if (capsule.getVariable() instanceof String) {
                    capsule.setVariable(combo.getSelection().toString());
                } else {
                    Object objet = combo.getSelection();
                    try {
                        capsule.setVariable(objet);
                    } catch (Exception e) {
                        System.err.println("FXfieldMan : l'objet extrait du combo de type " + objet.getClass().getSimpleName()
                                + " ne peut être inséré dans la variable correspondante !");
                    }
                }

            } else if (composant instanceof ListView) {
                if (capsule.getVariable() instanceof ArrayList) {
                    ArrayList listeVariable = (ArrayList) capsule.getVariable();
                    if (((ListView) composant).getSelectionModel().getSelectedItems().size() > 0) {
                        listeVariable.clear();
                        listeVariable.addAll(((ListView) composant).getSelectionModel().getSelectedItems());
                    } else {
                        listeVariable.clear();
                        listeVariable.addAll(((ListView) composant).getItems());
                    }
                } else if (capsule.getVariable() instanceof ObjetDi) {
                    if (((ListView) composant).getSelectionModel().getSelectedItem() instanceof ObjetDi) {
                        ObjetDi selection = (ObjetDi) ((ListView) composant).getSelectionModel().getSelectedItem();
                        capsule.setVariable(selection);
                    }
                } else {
                    capsule.setVariable(((ListView) composant).getSelectionModel().getSelectedItem());
                }
            } else if (composant instanceof TextField) {
                capsule.setVariable(((TextField) composant).getText());
            } else if (composant instanceof Label) {
                capsule.setVariable(((Label) composant).getText());
            } else if (composant instanceof CheckBox) {
                capsule.setVariable(((CheckBox) composant).isSelected());
            } else if (composant instanceof RadioButton) {
                capsule.setVariable(((RadioButton) composant).isSelected());
            } else if (composant instanceof TextArea) {
                capsule.setVariable(((TextArea) composant).getText());
            } else if (composant instanceof javafx.scene.control.DatePicker) {
                if (capsule.getVariable() instanceof Calendar) {
                    Calendar calendar = (Calendar) capsule.getVariable();
                    LocalDate localDate = ((javafx.scene.control.DatePicker) composant).getValue();
                    if (localDate != null) {
                        calendar.set(localDate.getYear(), localDate.getMonthValue() - 1, localDate.getDayOfMonth());
                    } else {
                        LocalDate aujourdhui = LocalDate.now();
                        calendar.set(aujourdhui.getYear(), aujourdhui.getMonthValue() - 1, aujourdhui.getDayOfMonth());
                    }
                } else if (capsule.getVariable() instanceof LocalDateTime) {
                    LocalDate localDate = extraire_date(
                            ((javafx.scene.control.DatePicker) composant).getEditor().getText());
                    if (localDate == null) {
                        localDate = ((DatePicker) composant).getValue();
                    }
                    if (localDate == null) {
                        localDate = LocalDate.now();
                    }
                    capsule.setVariable(localDate.atTime(12, 0));
                } else {
                    String s = "\nFieldManager : On ne peut pas mettre un " + capsule.getVariable().getClass() +
                            " dans un DatePicker !";
                    System.err.println(s);
                    ecrire_dans_log(s);
                }
            }
        }

    }

    private LocalDate extraire_date(String text) {
        LocalDate reponse;
        try {
            reponse = LocalDate.parse(text, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            return reponse;
        } catch (Exception exception) {
            try {
                return LocalDate.parse(text, DateTimeFormatter.ofPattern("dd/MM/yy"));
            } catch (Exception e) {
                return null;
            }
        }
    }


    /**
     * Désactive tous les Composants graphiques qui sont dans l'arrayList
     */
    public void disable_fields() {
        griser_champs(true);
    }

    private void griser_champs(Boolean vrai) {
        for (Entry<Node, Capsule> paire : entrySet()) {
            paire.getKey().setDisable(!vrai);
        }
    }

    /**
     * Active tous les Composants graphiques qui sont dans l'arrayList
     */
    public void enable_fields() {
        griser_champs(false);
    }


    // *** méthodes get/set

    public TextArea getLogArea() {
        if (logArea == null) {
            return new TextArea();
        }
        return logArea;
    }

    public void setLogArea(TextArea logArea) {
        this.logArea = logArea;
    }


    /**
     * Associe la liste des composants graphiques à null
     *
     * @param alx arraylist contenant les champs à nettoyer
     */

    public void setListeComposants(ArrayList<Node> alx) {
        clear();
        for (Node alx1 : alx) {
            put(alx1, null);
        }
    }


    // *** classes internes
}
