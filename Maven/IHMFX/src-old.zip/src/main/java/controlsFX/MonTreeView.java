package controlsFX;

import general.GestionnaireRetour;
import general.ObjetCSA;
import generalFX.ObjetIHM;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

import java.util.*;

public class MonTreeView extends TreeView<ObjetIHM> implements MaitreFX {
    private final String STRING_VIDE = "Vide !";
    private final Class<? extends ObjetCSA> type;
    Map<ObjetCSA, TreeItem<ObjetIHM>> itemMap = new HashMap<>();
    private MaitreFX maitre;
    private boolean isExpansionBusy = false;


    public MonTreeView(Class<? extends ObjetCSA> typeRacine) {
        type = Objects.requireNonNull(typeRacine,
                "Le type de MonTreeView ne peut être nul !");
        TreeItem<ObjetIHM> root = new TreeItem<>();
        setRoot(root);
        setShowRoot(false);

        configureCellFactory();
        configureSelectionListener();
    }

    private void configureCellFactory() {
        setCellFactory(tv -> {
            TreeCellAvecBoutons cell = new TreeCellAvecBoutons();

            // Handler pour l'ajout d'une sous-catégorie
            cell.setOnAjouter(treeItem -> {
                if (treeItem != null && treeItem.getValue() != null) {
                    action_ajouter_sous_categorie(treeItem);
                }
            });

            // Handler pour le rafraîchissement
            cell.setOnRafraichir(treeItem -> {
                if (treeItem != null && treeItem.getValue() != null) {
                    action_rafraichir_sous_categories(treeItem);
                }
            });

            return cell;
        });
    }


    private void configureSelectionListener() {
        getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!isExpansionBusy && newValue != null && newValue.getValue() != null) {
                prevenir_ecouteur(newValue.getValue().getObjetCSA(), this, "clic");
            }
        });
    }

    private void action_ajouter_sous_categorie(TreeItem<ObjetIHM> parentItem) {
        ObjetCSA parent = parentItem.getValue().getObjetCSA();

        if (parent.getTypeEnfant() == null) {
            affiche_console("** Type de sous-catégorie non défini pour " + parentItem);
            affiche_utilisateur("Impossible d'ajouter une sous-catégorie");
            return;
        }

        if (maitre == null) {
            affiche_console("** MaitreFX non défini pour " + this);
            affiche_utilisateur("Impossible d'ajouter une sous-catégorie");
            return;
        }

        creer_sous_categorie(parent);
    }

    private void creer_sous_categorie(ObjetCSA parent) {
        ObjetCSA reference = maitre.getElementFromType(parent.getTypeEnfant());

        if (reference != null) {
            reference.setParent(parent);
            charger_donnees_vers_enfant(reference);
            return;
        }

        affiche_console("MonTreeView/creer_sous_categorie : Échec création instance de " +
                parent.getTypeEnfant());
        affiche_utilisateur("Impossible de créer une sous-catégorie pour " + parent);
    }

    private void action_rafraichir_sous_categories(TreeItem<ObjetIHM> parentItem) {
        ObjetCSA parent = parentItem.getValue().getObjetCSA();

        if (parent.getTypeEnfant() == null) {
            affiche_console("** Type de sous-catégorie non défini pour " + parentItem);
            affiche_utilisateur("Impossible de rafraichir les sous-catégories de " +
                    parent);
            return;
        }

        if (maitre == null) {
            affiche_console("** MaitreFX non défini pour " + this);
            return;
        }
        ObjetCSA enfant = maitre.getElementFromType(parent.getTypeEnfant());
        enfant.setParent(parent);

        affiche_console("Rafraîchissement des sous-catégories de " + parent);
        affiche_utilisateur("Rafraîchissement en cours...");

        // Code 4 = demande de liste des sous-catégories
        maitre.envoyer_vers_parent(4,
                enfant,
                new RafraichisseurEnfants(parentItem));
    }

    private TreeItem<ObjetIHM> creer_treeItem(ObjetCSA objetDi) {
        return new TreeItem<>(new ObjetIHM(objetDi));
    }

    private void prevenir_ecouteur(ObjetCSA selectedItem, MonTreeView monTreeView, String info) {
        if (maitre == null) {
            System.err.println("\n!!!\nEcouteurFX non spécifié pour le TreeView " + this);
            return;
        }
        maitre.action_utilisateur(selectedItem, monTreeView, info);
    }


    public void setMaitre(MaitreFX maitre) {
        this.maitre = maitre;
    }


    public void setData(List<? extends ObjetCSA> objetDis) {
        getRoot().getChildren().clear();
        itemMap.clear();
        addData(objetDis);
    }

    public void addDataList(List<? extends ObjetCSA> liste) {
        ArrayList<ObjetCSA> descendants = new ArrayList<>();
        for (ObjetCSA objetDi : liste) {
            ObjetCSA parent = objetDi.getParent();
            if (parent == null || parent.getId() == 0) {
                TreeItem<ObjetIHM> nouveauParent = create_node(objetDi);
                ajout_special(getRoot().getChildren(), nouveauParent);
                itemMap.putIfAbsent(objetDi, nouveauParent);
            } else {
                descendants.add(objetDi);
            }
        }
        descendants.forEach(this::addDescendant);
    }

    private void addDescendant(ObjetCSA objetDi) {
        TreeItem<ObjetIHM> treeItem = create_node(objetDi);
        ObjetCSA leParent = objetDi.getParent();

        if (leParent == null) {
            System.err.println("MonTreeView/addDescendant : " + objetDi +
                    " n'a pas de parent. Ajout ignoré !");
            return;
        }

        for (Map.Entry<ObjetCSA, TreeItem<ObjetIHM>> noeud : itemMap.entrySet()) {
            if (insertion_reussie(objetDi, noeud.getValue())) {
                return;
            }
        }

        System.err.println("MonTreeView/addDescendant : " + objetDi +
                " n'a pas trouvé son parent. Ajout ignoré !");
    }

    private boolean insertion_reussie(ObjetCSA objetDi, TreeItem<ObjetIHM> treeItem) {
        ObjetCSA parent = objetDi.getParent();
        TreeItem<ObjetIHM> nouvelElement = create_node(objetDi);

        if (parent.equals(treeItem.getValue().getObjetCSA())) {
            ajout_special(treeItem.getChildren(), nouvelElement);
            return true;
        }

        for (TreeItem<ObjetIHM> enfant : treeItem.getChildren()) {
            if (insertion_reussie(objetDi, enfant)) {
                return true;
            }
        }
        return false;
    }

    private void ajout_special(ObservableList<TreeItem<ObjetIHM>> treeItems,
                               TreeItem<ObjetIHM> treeItem) {
        if (treeItems.size() == 1) {
            TreeItem<ObjetIHM> ancienItem = treeItems.get(0);
            if (ancienItem.getValue().toString().equals(STRING_VIDE)) {
                treeItems.clear();
                treeItems.add(treeItem);
                return;
            }
        }

        ObjetIHM itemIHM = treeItem.getValue();
        for (TreeItem<ObjetIHM> iter : treeItems) {
            if (iter.getValue().equals(itemIHM)) {
                return;
            }
        }
        treeItems.add(treeItem);
    }

    public void clear() {
        getRoot().getChildren().clear();
        itemMap.clear();
    }

    public void clear_children() {
        for (TreeItem<ObjetIHM> parent : getRoot().getChildren()) {
            parent.getChildren().clear();
            parent.getChildren().add(creer_treeItem(creer_objet_vide()));
        }
        itemMap.clear();
    }

    private TreeItem<ObjetIHM> create_node(ObjetCSA objetDi) {
        TreeItem<ObjetIHM> treeItem = creer_treeItem(objetDi);

        // N'ajouter un placeholder QUE si l'objet peut avoir des enfants
        if (objetDi.getTypeEnfant() != null) {
            treeItem.getChildren().add(creer_treeItem(creer_objet_vide()));

            treeItem.expandedProperty().addListener(new ChangeListener<Boolean>() {
                @Override
                public void changed(ObservableValue<? extends Boolean> observable,
                                    Boolean oldValue, Boolean newValue) {
                    isExpansionBusy = true;
                    String action = newValue ? "expanded" : "collapsed";
                    System.out.println(objetDi + " " + action);
                    prevenir_ecouteur(objetDi, MonTreeView.this, action);
                    Platform.runLater(() -> isExpansionBusy = false);
                }
            });
        }
        // Sinon, c'est une feuille → pas d'enfants, pas de listener, pas expandable

        return treeItem;
    }

    private ObjetCSA creer_objet_vide() {
        return new ObjetCSA("Object", "id", STRING_VIDE) {
            @Override
            public ObjetCSA getParent() {
                return null;
            }

            @Override
            public void setParent(ObjetCSA objetDi) {
            }

            @Override
            public ObjetCSA getObjetFromType(String s) {
                return null;
            }

            @Override
            public void reinitialiser() {
            }

            @Override
            public String toString() {
                return STRING_VIDE;
            }
        };
    }

    // ============ Implémentation MaitreFX ============

    @Override
    public void envoyer_vers_parent(int code, Object objet, GestionnaireRetour gestionnaire) {
        if (maitre != null) {
            maitre.envoyer_vers_parent(code, objet, gestionnaire);
        }
    }

    @Override
    public void affiche_utilisateur(String texte) {
        if (maitre != null) {
            maitre.affiche_utilisateur(texte);
        }
    }

    @Override
    public void affiche_console(String texte) {
        if (maitre != null) {
            maitre.affiche_console("MonTreeView : " + texte);
        } else {
            System.out.println("* MonTreeView : " + texte);
        }
    }

    @Override
    public ObjetCSA getElementFromType(String type) {
        if (maitre != null) {
            return maitre.getElementFromType(type);
        }
        return null;
    }

    @Override
    public void action_utilisateur(Object selectedItem, Object source, String extraInfo) {
        if (maitre != null) {
            maitre.action_utilisateur(selectedItem, source, extraInfo);
        }
    }

    @Override
    public void affiche_details(Object selectedItem) {
        if (maitre != null) {
            maitre.affiche_details(selectedItem);
        }
    }

    @Override
    public void nettoyer_champs() {
        clear();
    }

    @Override
    public void charger_donnees_vers_enfant(ObjetCSA objetCSA) {
        if (maitre instanceof EditorPaneController) {
            String heritedPath = ((EditorPaneController) maitre).getEditorPath();
            EditorPaneController.openEditor(objetCSA,
                    this,
                    null,
                    heritedPath);
            return;
        }
        EditorPaneController.openEditor(objetCSA, this, null, "");
    }

    @Override
    public void rafraichir() {
        if (maitre == null) {
            affiche_utilisateur("rafraichissement impossible pour cet élément");
            affiche_console("Aucun accès à la bd pour cet objet. Il faut initialiser " +
                    "son maitreFX !");
            return;
        }
        // Rafraîchir la vue complète
        try {
            ObjetCSA instance = type.getDeclaredConstructor().newInstance();
            maitre.envoyer_vers_parent(4, instance, new GestionnaireRetour() {
                @Override
                public void traitementRetour(ArrayList arrayList) {
                    Platform.runLater(() -> {
                        List<ObjetCSA> categories = new ArrayList<>();
                        for (Object obj : arrayList) {
                            if (obj instanceof ObjetCSA) {
                                categories.add((ObjetCSA) obj);
                            }
                        }
                        setData(categories);
                    });
                }
            });
        } catch (Exception e) {
            affiche_console("Erreur lors du rafraîchissement : " + e.getMessage());
        }
    }

    @Override
    public boolean isTest() {
        return maitre != null && maitre.isTest();
    }

    /**
     * Ajoute ou met à jour des données dans le TreeView
     * Si un objet existe déjà (même ID et type), il est écrasé
     * Sinon, il est ajouté
     *
     * @param objetDis liste des objets à ajouter/mettre à jour
     */
    public void addData(List<? extends ObjetCSA> objetDis) {
        ArrayList<ObjetCSA> descendants = new ArrayList<>();

        for (ObjetCSA objetDi : objetDis) {
            ObjetCSA parent = objetDi.getParent();

            // Vérifier si l'objet existe déjà
            TreeItem<ObjetIHM> existingItem = trouver_item_existant(objetDi);

            if (parent == null || parent.getId() == 0) {
                // C'est un élément racine
                if (existingItem != null) {
                    // Mettre à jour l'objet existant
                    existingItem.getValue().setObjetCSA(objetDi);
                    itemMap.put(objetDi, existingItem);
                } else {
                    // Ajouter comme nouveau
                    TreeItem<ObjetIHM> nouveauParent = create_node(objetDi);
                    ajout_special(getRoot().getChildren(), nouveauParent);
                    itemMap.put(objetDi, nouveauParent);
                }
            } else {
                // C'est un descendant, traiter après
                descendants.add(objetDi);
            }
        }

        // Traiter les descendants
        descendants.forEach(this::addOrUpdateDescendant);
    }

    /**
     * Trouve un TreeItem existant correspondant à l'objetCSA
     * La comparaison se fait sur l'ID et le type
     */
    private TreeItem<ObjetIHM> trouver_item_existant(ObjetCSA objetDi) {
        for (Map.Entry<ObjetCSA, TreeItem<ObjetIHM>> entry : itemMap.entrySet()) {
            ObjetCSA existing = entry.getKey();

            // Comparaison par ID et type
            if (existing.getId() == objetDi.getId() &&
                    existing.getType().equals(objetDi.getType())) {
                return entry.getValue();
            }
        }
        return null;
    }

    /**
     * Ajoute ou met à jour un descendant dans l'arbre
     */
    private void addOrUpdateDescendant(ObjetCSA objetDi) {
        ObjetCSA leParent = objetDi.getParent();

        if (leParent == null) {
            System.err.println("MonTreeView/addOrUpdateDescendant : " + objetDi +
                    " n'a pas de parent. Ajout ignoré !");
            return;
        }

        // Vérifier si l'objet existe déjà
        TreeItem<ObjetIHM> existingItem = trouver_item_existant(objetDi);

        if (existingItem != null) {
            // Mettre à jour l'objet existant
            existingItem.getValue().setObjetCSA(objetDi);
            itemMap.put(objetDi, existingItem);
            return;
        }

        // Sinon, ajouter comme nouveau
        TreeItem<ObjetIHM> treeItem = create_node(objetDi);

        for (Map.Entry<ObjetCSA, TreeItem<ObjetIHM>> noeud : itemMap.entrySet()) {
            if (insertion_reussie(objetDi, noeud.getValue())) {
                return;
            }
        }

        System.err.println("MonTreeView/addOrUpdateDescendant : " + objetDi +
                " n'a pas trouvé son parent. Ajout ignoré !");
    }

    private class RafraichisseurEnfants implements GestionnaireRetour {
        private final TreeItem<ObjetIHM> parentItem;

        public RafraichisseurEnfants(TreeItem<ObjetIHM> parentItem) {
            this.parentItem = parentItem;
        }

        @Override
        public void traitementRetour(ArrayList arrayList) {
            if (arrayList == null || arrayList.isEmpty()) {
                affiche_console("Liste vide reçue pour rafraîchissement");
                Platform.runLater(() -> {
                    parentItem.getChildren().clear();
                    parentItem.getChildren().add(creer_treeItem(creer_objet_vide()));
                    affiche_utilisateur("Aucune sous-catégorie");
                });
                return;
            }

            Platform.runLater(() -> {
                // Supprimer le placeholder "Vide !"
                parentItem.getChildren().removeIf(item ->
                        item.getValue().toString().equals(STRING_VIDE));

                // Vider les enfants existants
                parentItem.getChildren().clear();

                // Ajouter les nouvelles sous-catégories
                for (Object obj : arrayList) {
                    if (obj instanceof ObjetCSA) {
                        ObjetCSA categorie = (ObjetCSA) obj;
                        TreeItem<ObjetIHM> nouveauItem = create_node(categorie);
                        parentItem.getChildren().add(nouveauItem);
                        itemMap.put(categorie, nouveauItem);
                    }
                }

                // Si toujours vide, remettre le placeholder
                if (parentItem.getChildren().isEmpty()) {
                    parentItem.getChildren().add(creer_treeItem(creer_objet_vide()));
                }

                affiche_utilisateur("Sous-catégories rafraîchies");
            });
        }
    }
}