package controlsFX;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import general.GestionnaireRetour;
import general.Monostable;
import general.ObjetCSA;
import generalFX.CustomEditor;
import generalFX.GestionnaireListesFX;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.text.Normalizer;
import java.util.*;
import java.util.function.Consumer;

/**
 * FXML Controller class
 *
 * @author didiertowe
 */
public class ComboEditableController<T> extends HBox
        implements Initializable, MaitreFX {

    private static final int MAX_RESULTATS_COMBO = 50;        // Limite affichage
    private static final int LIMITE_AFFICHAGE_AUTO = 10;      // Auto-show si ≤ 10
    private static final boolean DEBUG_COMBO = true;
    private final TreeMap<String, Object> hashOriginale = new TreeMap<>();
    private final TreeMap<String, Object> hashComplete = new TreeMap<>(); // backup complet
    private final Monostable actionEnabler = new Monostable(true, false);
    @FXML
    private ComboBox<String> combo;
    @FXML
    private Button btnEffacer, btnAjouter, btnRafraichir;
    private Object selection = null;
    private MaitreFX maitre;
    private Class<T> type;
    private CustomEditor editeurPersonnel = null;
    private boolean isProgrammaticChange = false;
    private Consumer<ObjetCSA> postCreateCallback;
    private int previousTextLength = 0;


    public ComboEditableController(Class<T> type) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/ComboEditable.fxml"));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        this.type = Objects.requireNonNull(type, "Type cannot be null");
    }


    public Class<T> getType() {
        return type;
    }

    public void setType(Class<T> type) {
        this.type = type;
    }

    private void log(String msg) {
        if (!DEBUG_COMBO) return;
        System.out.printf("[ComboEditable %s] %s%n",
                type != null ? type.getSimpleName() : "?", msg);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnEffacer.setTooltip(new Tooltip("Permet de réinitialiser la sélection"));
        btnAjouter.setTooltip(new Tooltip("Permet de créer un nouvel item"));
        btnRafraichir.setTooltip(new Tooltip("Permet de rafraichir le contenu de la liste déroulante"));
        // Add this in your initialization code pour éviter la désynchronisation entre les clics et la selection
        combo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            log("SELECTION changed: '" + oldVal + "' -> '" + newVal +
                    "', isProgrammatic=" + isProgrammaticChange);
            if (isProgrammaticChange) {
                return; // ← IGNORER les changements programmatiques
            }
            if (newVal == null) {
                return;
            }
            if (newVal.equals(oldVal)) {  // ← AJOUT : évite les doublons
                return;
            }
            if (!actionEnabler.isStable()) {  // ← MODIF : vérifier AVANT
                return;
            }

            actionEnabler.go();  // ← MODIF : bloquer IMMÉDIATEMENT

            selection = hashOriginale.get(newVal);
            if (maitre != null) {
                maitre.action_utilisateur(selection, this, "choix combo effectué");
            }
        });
        // Info visuelle si liste tronquée
        combo.setOnShowing((x) -> {
            if (hashComplete.size() > MAX_RESULTATS_COMBO) {
                combo.setPromptText(String.format("%d résultats, donc tapez pour filtrer)", hashComplete.size()));
            }
        });
        // Tronque les items trop longs dans la liste déroulante
        combo.setCellFactory(lv -> new javafx.scene.control.ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String texte = item.length() > 25 ? item.substring(0, 22) + "..." : item;
                    setText(texte);
                    setTooltip(new Tooltip(item)); // Affiche le texte complet au survol
                }
            }
        });
        combo.getEditor().textProperty().addListener((obs, ov, nv) -> {
            log("EDITOR text: '" + ov + "' -> '" + nv + "'");
        });

        combo.getItems().addListener((javafx.collections.ListChangeListener<String>) c -> {
            log("ITEMS changed, size=" + combo.getItems().size());
        });
        combo.getEditor().addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ENTER) {
                // Si une sélection est déjà faite, on ferme juste le dropdown
                combo.hide();
            }
        });

    }


    public MaitreFX getMaitre() {
        return maitre;
    }

    public void setMaitre(MaitreFX maitre) {
        this.maitre = maitre;
    }


    @FXML
    public void action_effacer(ActionEvent action) {
        log("action_effacer() déclenchée");

        affiche_console("Demande d'effacement de la sélection du combo " + this);
        Platform.runLater(() -> {
            combo.getEditor().clear();
            selection = null;
            restaurer_liste_initiale();  // ← Pas de prevenir_parent !
        });
    }

    @FXML
    public void action_ajouter(ActionEvent action) {
        if (type == null) {
            affiche_console("** Element de référence inconnu dans " + this);
            affiche_utilisateur("Impossible d'ajouter un nouvel élément dans cette liste " +
                    "déroulante");
            return;
        }
        if (maitre == null) {
            affiche_console("** MaitreFX non défini pour " + this);
            affiche_utilisateur("Impossible d'ajouter un nouvel élément dans cette liste " +
                    "déroulante");
            return;
        }

        // Par défaut, c'est l'instanciation par défaut qui est exécutée
        if (ObjetCSA.class.isAssignableFrom(type)) { // thanks GPT !
            try {
                // Dynamically create a new instance of the provided subclass
                ObjetCSA instance = (ObjetCSA) type.getDeclaredConstructor().newInstance();
                // permet de faire des modifs à l'objet de référence
                if (postCreateCallback != null) postCreateCallback.accept(instance);
                charger_donnees_vers_enfant(instance);
                return;
            } catch (InstantiationException | IllegalAccessException | NoSuchMethodException |
                     InvocationTargetException e) {
                affiche_console("ComboEditable/action_ajouter : Failed to create an instance of " + type.getName());
                affiche_utilisateur("Impossible d'ajouter un nouvel élément dans cette liste " +
                        "déroulante");
                return;
            }
        }
        affiche_console("** " + this + " ne gère pas l'ajout de " + type);
        affiche_utilisateur("Impossible d'ajouter un objet de type <" + type + ">");
    }

    @FXML
    public void action_rafraichir(ActionEvent action) {
        if (type == null) {
            affiche_console("** Element de référence inconnu dans " + this);
            affiche_utilisateur("Impossible de rafraichir cette liste " +
                    "déroulante");
            return;
        }

        rafraichir_liste();
    }

    public void fireModification() {
        if (maitre == null) {
            System.err.println("** ComboFiltrable/fireModification : Je n'ai pas de maitreFX :-(" +
                    ". Je laisse tomber !");
            return;
        }
        maitre.action_utilisateur(selection, this, "modification du combeEditable");
    }

    public void setTextEditable(boolean editable) {
        Platform.runLater(() -> {
            combo.getEditor().setEditable(editable);
        });
    }

    public String getTexte() {
        return combo.getEditor().getText();
    }

    public void setTexte(String texte) {
        Platform.runLater(() -> {
            combo.getEditor().setText(texte);
        });

    }

    private void restaurer_liste_initiale() {
        log("restaurer_liste_initiale(), hashComplete.size=" + hashComplete.size());

        hashOriginale.clear();
        int compteur = 0;
        for (Map.Entry<String, Object> entry : hashComplete.entrySet()) {
            if (compteur >= MAX_RESULTATS_COMBO) break;
            hashOriginale.put(entry.getKey(), entry.getValue());
            compteur++;
        }

        Platform.runLater(() -> {
            isProgrammaticChange = true;
            try {
                combo.getItems().setAll(hashOriginale.keySet());
                combo.getSelectionModel().clearSelection();
                if (hashComplete.size() > MAX_RESULTATS_COMBO) {
                    combo.setPromptText(String.format("Affichage %d/%d - Tapez pour filtrer",
                            MAX_RESULTATS_COMBO, hashComplete.size()));
                } else {
                    combo.setPromptText(type == null ? "" : type.getSimpleName());
                }
            } finally {
                isProgrammaticChange = false;
            }
        });
    }

    @FXML
    public void action_filtrer(KeyEvent event) {
        log("action_filtrer() event=" + (event != null ? event.getCode() : "null") +
                ", texte='" + combo.getEditor().getText() + "'");

        if (!actionEnabler.isStable() && event == null) {
            System.out.println("Action en doublon détectée");
            return;
        }
        actionEnabler.go();

        String texteTape = combo.getEditor().getText().trim();
        int currentLength = texteTape.length();
        boolean isBackspace = (event != null && event.getCode() == KeyCode.BACK_SPACE);
        boolean isDelete = (event != null && event.getCode() == KeyCode.DELETE);
        boolean isEnter = (event != null && event.getCode() == KeyCode.ENTER);
        boolean isShrinking = currentLength < previousTextLength;
        previousTextLength = currentLength;
        String texte = Normalizer.normalize(texteTape.toUpperCase(),
                Normalizer.Form.NFD).replaceAll("[\\u0300-\\u036F]", "");

        // Texte vide = restaurer premiers MAX_RESULTATS
        if (texte.isEmpty()) {
            restaurer_liste_initiale();
            if (event != null) {
                combo.hide();  // Fermer la taille du dropdown s'est adaptée à la précédente recherche
                Platform.runLater(() -> combo.show());  // Rouvrir dans un nouveau cycle
            }
            return;
        }

        // Filtrage avec limite de résultats
        TreeMap<String, Object> inclus = new TreeMap<>();
        int compteur = 0;
        log("Filtre: texte='" + texte + "', hashComplete.size=" + hashComplete.size());
        for (Map.Entry<String, Object> entry : hashComplete.entrySet()) {
            if (compteur >= MAX_RESULTATS_COMBO) break;

            String nom = entry.getKey();
            String selectionString = Normalizer.normalize(nom.trim().toUpperCase(),
                    Normalizer.Form.NFD).replaceAll("[\u0300-\u036F]", "");

            if (selectionString.startsWith(texte)) {
                log("  MATCH: '" + nom + "'");
                inclus.put(nom, entry.getValue());
                compteur++;
            }
        }
        log("Résultats filtrés: " + inclus.size());

        // Mettre à jour hashOriginale
        hashOriginale.clear();
        hashOriginale.putAll(inclus);

        // Affichage avec indication si liste tronquée
        int finalCompteur = compteur;
        boolean doAutocomplete = !isBackspace && !isDelete && !isShrinking;
        Platform.runLater(() -> {
            isProgrammaticChange = true;  // on va toucher au combo et il va travailler
            try {
                combo.getItems().setAll(inclus.keySet());
                combo.getSelectionModel().clearSelection();
                selection = null;

                if (doAutocomplete && !inclus.isEmpty() && !texteTape.isEmpty()) {
                    String premier = inclus.firstKey();
                    // sécurité
                    if (premier.length() >= texteTape.length()) {
                        combo.getEditor().setText(premier);
                        int start = texteTape.length();
                        combo.getEditor().selectRange(start, premier.length());
                    }
                } else {
                    // En cas de backspace / delete / shrink : on laisse exactement ce que l'utilisateur a tapé
                    combo.getEditor().setText(texteTape);
                    combo.getEditor().positionCaret(texteTape.length());
                }

                // Affichage du menu déroulant
                if (!inclus.isEmpty() && inclus.size() <= LIMITE_AFFICHAGE_AUTO && !isEnter) {
                    combo.hide();  // Fermer la taille du dropdown s'est adaptée à la précédente recherche
                    Platform.runLater(() -> combo.show());  // Rouvrir dans un nouveau cycle
                }

                // ENTER seul déclenche la vraie sélection + prevenir_parent
                if (event != null && event.getCode() == KeyCode.ENTER && !inclus.isEmpty()) {
                    selection = inclus.firstEntry().getValue();
                    combo.getSelectionModel().select(inclus.firstKey());
                    combo.hide();
                    prevenir_parent(selection, event);
                }
            } finally {
                isProgrammaticChange = false;
            }
        });
    }


    private void prevenir_parent(Object o, Event event) {
        if (maitre != null) {
            maitre.action_utilisateur(o, this, String.valueOf(event));
            return;
        }
        System.err.println("Didier : le comboEditable ne connaît pas son maitreFX !");
    }


    // Méthode pour encapsuler les changements programmatiques
    private void selectProgrammatically(String key) {
        isProgrammaticChange = true;
        try {
            combo.getSelectionModel().select(key);
        } finally {
            isProgrammaticChange = false;
        }
    }


    public void setListe(Collection<?> liste) {
        log("setListe() appelée, taille=" + (liste != null ? liste.size() : -1));

        isProgrammaticChange = true;
        try {
            hashOriginale.clear();
            hashComplete.clear();
            selection = null;
            // Trier la collection si ce sont des ObjetCSA
            List<?> listeTrie = new ArrayList<>(liste);
            if (!listeTrie.isEmpty() && listeTrie.get(0) instanceof ObjetCSA) {
                Collections.sort((List<ObjetCSA>) listeTrie);
            }

            for (Object elt : listeTrie) {
                if (type.isInstance(elt)) {
                    hashComplete.put(elt.toString(), elt);
                } else {
                    affiche_console("Insertion non autorisée de " + elt + " dans la liste " + this);
                }
            }
            log("Après setListe, hashComplete a la taille : " + hashComplete.size());
            // Afficher les premiers MAX_RESULTATS_COMBO
            restaurer_liste_initiale();
        } finally {
            isProgrammaticChange = false;
        }
    }


    public void setListeWithSelection(Collection<?> liste, Object aSelectionner) {
        affiche_console("je rafraichis la liste avec " + liste +
                "\nEt je vais y sélectionner si possible " + aSelectionner +
                "\nL'ancienne sélection vaut : " + selection);
        isProgrammaticChange = true;
        try {
            // 1) Alimenter hashComplete + items via la mécanique standard
            setListe(liste);  // ← IMPORTANT : remplit hashComplete et affiche les premiers éléments

            // 2) Gérer la sélection si demandée
            Object cible = (aSelectionner == null) ? selection : aSelectionner;
            if (cible == null) {
                return; // rien à sélectionner
            }

            // Chercher dans hashComplete
            Object found = null;
            String cleTrouvee = null;
            for (Map.Entry<String, Object> e : hashComplete.entrySet()) {
                if (isEquivalent(e.getValue(), cible)) {
                    found = e.getValue();
                    cleTrouvee = e.getKey();
                    break;
                }
            }

            if (found != null) {
                Object finalSelection = found;
                String finalKey = cleTrouvee;
                Platform.runLater(() -> {
                    selection = finalSelection;
                    combo.getSelectionModel().select(finalKey);
                });
            } else {
                Platform.runLater(() -> {
                    selection = null;
                    combo.getSelectionModel().clearSelection();
                    // NE PAS toucher à l’editor ici, le filtre s’en charge
                });
            }
        } finally {
            isProgrammaticChange = false;
        }
    }

    /**
     * Méthode utilitaire pour comparer deux objets de manière robuste
     */
    private boolean isEquivalent(Object obj1, Object obj2) {
        if (obj1 == null || obj2 == null) {
            return false;
        }

        // Comparaison standard
        if (obj1.equals(obj2)) {
            return true;
        }

        // Comparaison spéciale pour ObjetCSA (par ID et type)
        if (obj1 instanceof ObjetCSA && obj2 instanceof ObjetCSA) {
            ObjetCSA cibleCSA = (ObjetCSA) obj1;
            ObjetCSA eltCSA = (ObjetCSA) obj2;
            // Même type requis
            if (!cibleCSA.getType().equals(eltCSA.getType())) {
                return false;
            }

            // Si les deux ont un ID valide, comparer par ID
            if (cibleCSA.getId() > 0 && eltCSA.getId() > 0) {
                return cibleCSA.getId() == eltCSA.getId();
            } else {
                // Sinon, comparer par nom (toString)
                return cibleCSA.toString().equals(eltCSA.toString());
            }
        }

        return false;
    }

    public void setListeKeepSelection(Collection<?> liste) {
        setListeWithSelection(liste, null);
    }

    ArrayList<Object> getListeComplete() {
        return new ArrayList<>(hashOriginale.entrySet());
    }

    public void clearSelection() {
        action_effacer(null);
    }

    public void clear() {
        setListe(new ArrayList<>());
    }


    private TextField getTextField() {
        return combo.getEditor();
    }

    public Object getSelection() {
        if (selection == null && type == String.class) {
            return "";
        }
        return selection;
    }


    /**
     * Sélectionne un objet avec possibilité de mode silencieux
     *
     * @param nouveau l'élément à sélectionner
     * @param silent  si true, ne déclenche pas d'événement utilisateur
     * @return vrai si l'élément a été trouvé et sélectionné
     */
    private boolean selectInternal(Object nouveau, boolean silent) {
        if (nouveau == null) {
            clearSelection();
            return false;
        }

        // 1. Trouver la clef (String) correspondant à l'objet (Object)
        String clefToSelect = null;

        if (nouveau instanceof String) {
            if (combo.getItems().contains(nouveau)) {
                clefToSelect = (String) nouveau;
            }
        } else {
            for (Map.Entry<String, Object> paires : hashOriginale.entrySet()) {
                if (nouveau.equals(paires.getValue()) ||
                        (nouveau instanceof ObjetCSA && isEquivalent(nouveau, paires.getValue()))) { // Utilisez isEquivalent ici
                    selection = paires.getValue();
                    clefToSelect = paires.getKey();
                    break;
                }
            }
        }

        if (clefToSelect == null) {
            clearSelection();
            // Optionnel : maintenir l'erreur pour débogage
            if (!hashOriginale.isEmpty()) {
                System.err.println("** ComboEditableController : échec de sélection de " + nouveau +
                        " dans une liste qui contient : " + hashOriginale.values());
            }
            return false;
        }

        // 2. Effectuer la sélection (asynchrone)
        String finalClefToSelect = clefToSelect;
        Platform.runLater(() -> {
            // Le drapeau n'est mis à jour que DANS l'action réelle sur l'UI,
            // garantissant qu'elle ne soit pas annulée par un autre événement.
            isProgrammaticChange = true;
            try {
                combo.getSelectionModel().select(finalClefToSelect);
                selection = hashOriginale.get(finalClefToSelect);
            } finally {
                isProgrammaticChange = false;
            }

            // 3. Déclencher l'événement UNIQUEMENT si NON silencieux
            if (!silent && maitre != null) {
                maitre.action_utilisateur(selection, ComboEditableController.this, "sélection interne");
            }
        });

        return true;
    }

    /**
     * Sélectionne l'objet rentré
     *
     * @param nouveau c'est l'élément à sélectionner s'il existe dans la liste
     * @return vrai si l'élément est trouvé (et sélectionné); faux sinon
     */
    public boolean select(Object nouveau) {
        return selectInternal(nouveau, false);
    }

    /**
     * Sélectionne un objet sans déclencher d'événement utilisateur
     * Utile pour les chargements programmatiques
     *
     * @param nouveau l'élément à sélectionner
     * @return vrai si l'élément a été trouvé et sélectionné
     */
    public boolean selectSilently(Object nouveau) {
        return selectInternal(nouveau, true);
    }


    /**
     * Sélectionne l'objet rentré
     *
     * @param elementBD c'est l'élément à sélectionner s'il existe dans la liste, avec le même id (et
     *                  le même type)
     * @return vrai si l'élément est trouvé (et sélectionné); faux sinon. Auquel
     * cas, on a un clearSelection qui est opéré
     */
    public boolean select_with_id(ObjetCSA elementBD) {
        isProgrammaticChange = true;
        try {
            for (String item : combo.getItems()) {
                if (hashOriginale.get(item) instanceof ObjetCSA) {
                    ObjetCSA iter = (ObjetCSA) hashOriginale.get(item);
                    if (iter.getId() == elementBD.getId() &&
                            iter.getType().equals(elementBD.getType())) {
                        Platform.runLater(() -> {
                            combo.getSelectionModel().select(item);
                            selection = iter;
                        });
                        return true;
                    }
                }
            }
            clearSelection();
            return false;
        } finally {
            isProgrammaticChange = false;
        }
    }

    public Integer getIndiceSelectionne() {
        return combo.getSelectionModel().getSelectedIndex();
    }

    public void selectIndex(int i) {
        isProgrammaticChange = true;
        try {
            Platform.runLater(() -> {
                combo.getSelectionModel().select(i);
            });
        } finally {
            isProgrammaticChange = false;
        }
    }

    public void setPostCreateCallback(Consumer<ObjetCSA> callback) {
        this.postCreateCallback = callback;
    }

    @Override
    public void envoyer_vers_parent(int code, Object objet, GestionnaireRetour gestionnaireRetour) {
        if (objet.getClass().equals(type) && postCreateCallback != null) {
            // permet de faire des modifs à l'objet de référence
            postCreateCallback.accept((ObjetCSA) objet);
        }

        if (maitre == null) {
            affiche_console("Attention : le comboEditable " + this + " ne connait pas son maitre !");
            return;
        }

        // Cas particulier : c’est pour moi !
        boolean pourMoi = objet.getClass().equals(type) && code == 1;
        affiche_console("Demande d'ajout de : " + objet);
        maitre.envoyer_vers_parent(code,
                objet,
                new MonGestionnaireRetour(objet, pourMoi ? null : gestionnaireRetour));

    }


    @Override
    public void affiche_utilisateur(String texte) {
        if (maitre != null) {
            maitre.affiche_utilisateur(texte);
            return;
        }
        System.out.println("* Le comoEditable " + this +
                " ne connait pas son maitre et a essayé d'afficher <" + texte + ">");
    }

    @Override
    public void affiche_console(String texte) {
        if (maitre != null) {
            maitre.affiche_console("comboEditable : " + texte);
            return;
        }
        System.err.println("** Attention : le comoEditable " + this + " ne connait pas son maitre ! " +
                "Il a essayé d'afficher <" + texte + ">");
    }

    @Override
    public ObjetCSA getElementFromType(String type) {
        if (maitre != null) {
            return maitre.getElementFromType(type);
        }
        System.err.println("** Attention : le comoEditable " + this + " ne connait pas son maitre ! " +
                "Il a essayé de trouver sans succès le type de <" + type + ">");
        return null;
    }

    @Override
    public void action_utilisateur(Object selectedItem, Object source, String extraInfo) {
        // méthode inutile puisque le combo ne gère pas d'autres conteneurs
        // si ce n'est un customEditor
    }

    @Override
    public void affiche_details(Object selectedItem) {
        // pas de quoi afficher les détails ici
    }

    @Override
    public void nettoyer_champs() {
        action_filtrer(null);
    }

    /**
     * Supprime définitivement le bouton ajout
     */
    public void enlever_bouton_ajout() {
        getChildren().remove(btnAjouter);
    }

    public void setEditeurPersonnel(CustomEditor customEditor) {
        editeurPersonnel = customEditor;
    }

    /**
     * Supprime définitivement le bouton recharger
     */
    public void enlever_bouton_refresh() {
        getChildren().remove(btnRafraichir);
    }

    @Override
    public void charger_donnees_vers_enfant(ObjetCSA objetCSA) {
        String heritedPath = (maitre == null || !(maitre instanceof EditorPaneController)) ?
                "" :
                ((EditorPaneController) maitre).getEditorPath();
        ObjetCSA instance = getObjetReference();
        if (instance == null) {
            affiche_utilisateur("Aucune possibilité de gérer les éléments affichés ici");
            return;
        }
        String myObject = instance.getType();
        EditorPaneController.openEditor(objetCSA,
                this,
                editeurPersonnel,
                heritedPath.isEmpty() ? myObject : heritedPath + "." + myObject);
    }

    public ObjetCSA getObjetReference() {
        ObjetCSA instance = null;
        // Dynamically create a new instance of the provided subclass
        try {
            instance = (ObjetCSA) type.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            affiche_console("ComboEditable : Impossible de créer une instance de " + type);
            return null;
        }
        return instance;
    }

    @Override
    public void rafraichir() {
        action_filtrer(null);
    }

    public void rafraichir_liste() {
        if (maitre == null) {
            affiche_console("** " + this + " n'a pas de maitreFX, donc ne peut rafraichir son contenu");
            return;
        }
        affiche_console("Rafraichissement de la liste de " + type.getSimpleName());
        if (ObjetCSA.class.isAssignableFrom(type)) { // thanks GPT !
            try {
                // Dynamically create a new instance of the provided subclass
                ObjetCSA instance = (ObjetCSA) type.newInstance();
                // permet de faire des modifs à l'objet de référence
                if (postCreateCallback != null) postCreateCallback.accept(instance);

                affiche_utilisateur("Rafraichissement de la liste de " + instance.getPublicName());
                maitre.envoyer_vers_parent(4, instance, new GestionnaireListesFX(this));
                return;
            } catch (ClassCastException e) {
                affiche_console("ComboEditable/action_ajouter : ce combo ne contient pas d'objet BD " +
                        type.getName() + ". Rafraichissement impossible !");
                affiche_utilisateur("Impossible de rafraichir cette liste déroulante");
                return;
            } catch (InstantiationException e) {
                affiche_console("Le comboEditable n'arrive pas à instancier un objetCSA - IllegalInstanciation");
                return;
            } catch (IllegalAccessException e) {
                affiche_console("Le comboEditable n'arrive pas à instancier un objetCSA - IllegalAccess");
                return;
            }
        }
        affiche_console("** " + this + " ne gère pas le refresh de " + type);
        affiche_utilisateur("Impossible de rafraichir cette liste déroulante");
    }


    @Override
    public boolean isTest() {
        if (maitre == null) {
            return false;
        }
        return maitre.isTest();
    }

    private class MonGestionnaireRetour implements GestionnaireRetour {
        private final GestionnaireRetour autreGestionnaire;
        private final Object nouveau;

        protected MonGestionnaireRetour(Object selection, GestionnaireRetour GestionnaireRetour) {
            nouveau = selection;
            autreGestionnaire = GestionnaireRetour;
        }

        @Override
        public void traitementRetour(ArrayList arrayList) {
            if (arrayList.isEmpty()) {
                System.err.println("Le ComboEditable reçoit une liste vide de la BD !");
                return;
            }
            if (arrayList.get(0) instanceof Integer) {
                int code = (int) arrayList.get(0);
                // si c'est pour nous, l'autreGestionnaire sera NULL
                if (autreGestionnaire != null) {
                    autreGestionnaire.traitementRetour(arrayList);
                    return;
                }
                if (code == 1) {
                    affiche_utilisateur("Ajout réussi dans la base de données !");
                    if (type != null) {
                        if (nouveau instanceof ObjetCSA) {
                            ObjetCSA objetCSA = maitre.getElementFromType(((ObjetCSA) nouveau).getType());
                            // permet de faire des modifs à l'objet de référence
                            if (postCreateCallback != null) postCreateCallback.accept(objetCSA);
                            maitre.envoyer_vers_parent(4,
                                    objetCSA,
                                    new GestionnaireListesFX(ComboEditableController.this, nouveau));
                            return;
                        }
                        try {
                            ObjetCSA newInstance = (ObjetCSA) type.getDeclaredConstructor().newInstance();
                            // permet de faire des modifs à l'objet de référence
                            if (postCreateCallback != null) postCreateCallback.accept(newInstance);
                            maitre.envoyer_vers_parent(4,
                                    newInstance,
                                    new GestionnaireListesFX(ComboEditableController.this, newInstance));
                            return;
                        } catch (Exception x) {
                            affiche_console(type + " non-instantiable !!! Impossible de rafraichir la liste !");
                        }
                        return;
                    }
                    affiche_console("** Ajout réussi mais elt de référence inconnu ! Bizarre !");
                    return;
                }
                System.err.println("*** Le comboEditable reçoit un retour de requête inattendu " + arrayList + "\nJe m'attends à soit une liste, soit un objetDiIHM !");
                return;
            }
            System.err.println("Le comboEditable reçoit une requête non conforme : " + arrayList);
        }
    }
}
