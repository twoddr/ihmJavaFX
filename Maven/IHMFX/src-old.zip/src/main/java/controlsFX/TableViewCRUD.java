package controlsFX;

import general.GestionnaireRetour;
import general.ObjetCSA;
import generalFX.GenerateurColonnesTableView;
import generalFX.ObjetIHM;
import generalFX.TransformeurObjets;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

public class TableViewCRUD extends BorderPane
        implements MaitreFX {
    private final TreeSet<ObjetIHM> masterSet = new TreeSet<>();
    // The observable list for the table (can be rebuilt from the masterSet)
    private final ObservableList<ObjetIHM> tableItems = FXCollections.observableArrayList();
    private final ArrayList<Object> listeInitiale = new ArrayList<>();
    private final TableView<ObjetIHM> tableView = new TableView<>();
    private final MaitreFX maitreFX;// Your "single source of truth" sorted collection
    GenerateurColonnesTableView generateurColonnes;
    private ObjetCSA elementDeReference = null;
    private boolean isContentFree = false;
    private EditorPaneController editorPaneController = null;

    public TableViewCRUD(MaitreFX maitre) {
        super();
        maitreFX = Objects.requireNonNull(maitre, "maitre cannot be null");
        // icones
        Image addImage = new Image("images/add.png"); // From file system
        // or: new Image(getClass().getResourceAsStream("/images/icon.png"));
        Image suppImage = new Image("images/trash.png");
        Image modImage = new Image("images/edit.png");

        ImageView addIconView = new ImageView(addImage);
        addIconView.setFitWidth(20);  // Set size
        addIconView.setFitHeight(20); // Set size
        addIconView.setPreserveRatio(true);
        // Create buttons
        Button addButton = new Button("", addIconView);
        //addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        addButton.setOnAction(e -> showDialog(elementDeReference.getNewInstance()));

        ImageView suppImageView = new ImageView(suppImage);
        suppImageView.setFitWidth(20);  // Set size
        suppImageView.setFitHeight(20); // Set size
        suppImageView.setPreserveRatio(true);
        Button deleteButton = new Button("", suppImageView);
        //deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> deleteSelectedItem());


        ImageView modImageView = new ImageView(modImage);
        modImageView.setFitWidth(20);  // Set size
        modImageView.setFitHeight(20); // Set size
        modImageView.setPreserveRatio(true);
        Button modButton = new Button("", modImageView);
        //modButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
        modButton.setOnAction(e -> modifySelectedItem());
        // Button container
        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(10));
        buttonBox.getChildren().addAll(addButton, modButton, deleteButton);
        tableView.setRowFactory(tv -> {
            TableRow<ObjetIHM> row = new TableRow<>();

            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) {
                    // Get the item (object) from the row
                    ObjetIHM rowData = row.getItem();
                    showDialog(rowData.getObjetCSA());
                }
            });
            return row;
        });
        generateurColonnes = new GenerateurColonnesTableView(tableView, this);
        // Main layout
        setCenter(tableView);
        setTop(buttonBox);
    }

    public boolean isContentFree() {
        return isContentFree;
    }

    /**
     * Permet de définir le type de tableViewCRUD. Soit on peut y mettre des objets
     * libres, soit ceux-ci doivent provenir d'une liste définie
     *
     * @param contentFree true si libre
     */
    public void setContentFree(boolean contentFree) {
        isContentFree = contentFree;
    }

    private void updateTableViewFromSet() {
        tableItems.setAll(masterSet); // Rebuilds the list from the sorted set
    }

    private void modifySelectedItem() {
        ObjetIHM selection = tableView.getSelectionModel().getSelectedItem();
        if (selection == null) {
            String message = "Veuillez sélectionner un item svp";
            if (maitreFX == null) {
                System.out.println(message);
                return;
            }
            maitreFX.affiche_utilisateur(message);
            return;
        }
        showDialog(selection.getObjetCSA());
    }

    /**
     * Permet de charger les données dans la listeTable
     * Les données doivent être sous forme de liste
     *
     * @param donnees liste à insérer dans le tableau
     * @param ref     le type des données affichées (nomTable)
     *                si vide, alors ce sera le type du premier élément de la liste
     */
    public void charger_liste(ArrayList<Object> donnees, ObjetCSA ref) {
        listeInitiale.clear();
        listeInitiale.addAll(donnees);
        if (ref != null) {
            elementDeReference = ref.getNewInstance();
        } else {
            if (donnees.isEmpty() ||
                    !(donnees.get(0) instanceof ObjetCSA)) {
                Platform.runLater(() -> {
                    masterSet.clear();
                    updateTableViewFromSet();
                    tableView.setItems(tableItems);
                });
                return;
            }

            elementDeReference = ((ObjetCSA) donnees.get(0)).getNewInstance();
        }
        ArrayList<ObjetIHM> objetIHMS;
        objetIHMS = TransformeurObjets.transformer_en_objetsIHM(donnees, elementDeReference, this);

        generateurColonnes.setColumn(new ObjetIHM(elementDeReference));

        Platform.runLater(() -> {
            masterSet.clear();
            masterSet.addAll(objetIHMS);
            updateTableViewFromSet();
            tableView.setItems(tableItems);
        });
    }

    @Override
    public String toString() {
        return "[" + super.toString() + " ( " + (isContentFree ? "libre" : "contraint à ids") + ")]";
    }

    private void showDialog(ObjetCSA objetCSA) {
        editorPaneController = isContentFree ?
                new EditorPaneController() :
                new ListChooserController();
        affiche_console("$$DEBUG : le tablecrud " + this + " est " + (isContentFree ? "libre" : "verrouillé => liste"));

        String heritedPath = (maitreFX == null || !(maitreFX instanceof EditorPaneController)) ?
                "" :
                ((EditorPaneController) maitreFX).getEditorPath();
        if (elementDeReference == null) {
            affiche_utilisateur("Aucune possibilité de gérer les éléments affichés ici");
            return;
        }
        String myObject = elementDeReference.getType();
        editorPaneController = EditorPaneController.openEditor(objetCSA.getObjetRacine(),
                this,
                null,
                heritedPath.isEmpty() ? myObject : heritedPath + "." + myObject);
    }

    private void deleteSelectedItem() {
        ObjetIHM selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            showAlert("Information", "Veuillez sélectionner un élément à supprimer");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation de suppression");
        confirmation.setHeaderText("Supprimer l'élément ");
        confirmation.setContentText("Êtes-vous sûr de vouloir supprimer '" + selectedItem.getNom() + "' ?");

        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                tableView.getItems().remove(selectedItem);
                affiche_utilisateur("Item " + selectedItem + "supprimé avec succès");
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     *
     * @param code               le code du transfert. Par convention, si négatif,
     *                           il s'agit d'une opération interne. À ne pas envoyer vers la BD
     * @param objet              un objetIHM ou une liste d'objets IHM
     * @param gestionnaireRetour l'appelant
     */
    @Override
    public void envoyer_vers_parent(int code, Object objet, GestionnaireRetour gestionnaireRetour) {
        // séparer ce qui est pour moi et ce qui est pour mon parent
        if (objet instanceof ObjetCSA) {
            ObjetCSA objetCSA = (ObjetCSA) objet;
            if (objetCSA.getType().equals(elementDeReference.getType())) {
                remplacer_masterSet((ObjetCSA) objet);
                updateTableViewFromSet();
            }
            // Je le signale au-dessus(au cas où) !
            if (maitreFX != null) {
                maitreFX.action_utilisateur(objet, this, "appel de tableCRUD");
            }
            return;
        }
        if (objet instanceof List) {
            List<?> liste = (List<?>) objet;
            if (isListePourMoi(liste)) {
                liste.forEach(item -> {
                    if (item instanceof ObjetCSA) {
                        remplacer_masterSet((ObjetCSA) item);
                    } else {
                        affiche_console("TableViewCRUD/requete_BD : " + item + " aurait dû être de type " +
                                "objetCSA, mais est " + item + ". L'insertion sera ignorée !");
                    }
                });
                updateTableViewFromSet();
                return;
            }
        }
        affiche_console("* TableViewCRUD ne gère pas " + objet + " donc fait remonter la requête");
        remonter_vers_parent(code, objet, gestionnaireRetour);
    }

    private boolean isListePourMoi(List<?> liste) {
        for (Object item : liste) {
            if (item instanceof ObjetCSA &&
                    ((ObjetCSA) item).getType().equals(elementDeReference.getType())) {
                return true;
            }
        }
        return false;
    }

    private void remonter_vers_parent(int code, Object objet, GestionnaireRetour gestionnaireRetour) {
        if (maitreFX == null) {
            affiche_console("TableViewCRUD/remonter_vers_parent : je ne connais pas mon maitreFX, donc " +
                    "j'ignore l'appel : " + code + " - " + objet);
            return;
        }
        affiche_console("* Le tableviewCRUD envoie l'info " + code + " - " + objet +
                " vers son parent " + maitreFX);
        maitreFX.envoyer_vers_parent(code, objet, gestionnaireRetour);
    }

    private void remplacer_masterSet(ObjetCSA objet) {
        ObjetIHM nouvelItem = new ObjetIHM(remplacer_racine(objet));
        // 1. Remove the old version of this item from the TreeSet.
        //    This relies on your equals()/compareTo() method to find it.
        masterSet.remove(nouvelItem);
        // 2. Add the new item to the TreeSet. It will be inserted in the correct sorted position.
        masterSet.add(nouvelItem);
        // 3. Rebuild the ObservableList for the table. This will be fast and reflect the correct order.
    }

    private ObjetCSA remplacer_racine(ObjetCSA etranger) {
        ObjetCSA elu = null;
        for (ObjetIHM element : masterSet) {
            if (element.getObjetCSA().getObjetRacine().equals(etranger)) {
                elu = element.getObjetCSA();
                elu.setObjetRacine(etranger);
                break;
            }
        }
        return elu == null ? etranger : elu;
    }

    @Override
    public void affiche_utilisateur(String texte) {
        if (maitreFX == null) {
            System.out.println("* TableViewCRUD : " + texte);
            return;
        }
        maitreFX.affiche_utilisateur(texte);
    }

    @Override
    public void affiche_console(String texte) {
        if (maitreFX == null) {
            System.err.println("*** TableViewCRUD : " + texte);
            return;
        }
        maitreFX.affiche_console("TableViewCRUD : " + texte);
    }

    public MaitreFX getMaitreFX() {
        return maitreFX;
    }


    @Override
    public ObjetCSA getElementFromType(String type) {
        if (maitreFX == null) {
            System.err.println("*** Didier : Le TableViewCRUD ne connait pas son maitreFX." +
                    "\nPar conséquent il lui est impossible de créer un objet àpd " + type);
            return null;
        }
        return maitreFX.getElementFromType(type);
    }

    @Override
    public void action_utilisateur(Object selectedItem, Object source, String extraInfo) {
        // un de mes enfants me sollicite. Si je ne sais pas quoi faire, je fais remonter la patate chaude
        if (maitreFX == null) {
            affiche_console("TableViewCRUD " + this + " : je reçois un appel de " + source + " pour " +
                    selectedItem + ", mais " +
                    "je ne sais pas quoi en faire, donc j'ignore puisque je n'ai pas de maitreFX !");
            return;
        }
        maitreFX.action_utilisateur(selectedItem, source, extraInfo);
    }

    @Override
    public void affiche_details(Object selectedItem) {

    }

    @Override
    public void nettoyer_champs() {
        charger_liste(new ArrayList<>(), elementDeReference);
    }

    @Override
    public void charger_donnees_vers_enfant(ObjetCSA objetCSA) {

    }

    @Override
    public void rafraichir() {

    }

    public void rafraichir_listes() {
        if (editorPaneController == null) {
            affiche_console("Le tableCRUD ne peut rafraichir les listes internes car pas d'enfant initializé !");
            return;
        }
        editorPaneController.rafraichir_listes();
    }


    @Override
    public boolean isTest() {
        if (maitreFX == null) {
            return false;
        }
        return maitreFX.isTest();
    }

    public ObjetCSA getElementDeReference() {
        if (elementDeReference == null && !tableItems.isEmpty()) {
            ObjetIHM objetUniforme = tableItems.get(0);
            for (int index = 1; index < tableItems.size(); index++) {
                if (!objetUniforme.getType().equals(tableItems.get(index).getType())) {
                    return null;
                }
            }
            return objetUniforme.getObjetCSA().getNewInstance();
        }
        return elementDeReference;
    }

    public ArrayList getListe() {
        return new ArrayList<>(TransformeurObjets.transformer_en_objetsDi(tableItems));
    }

    public ArrayList<Object> getListeOriginale() {
        return listeInitiale;
    }

}
