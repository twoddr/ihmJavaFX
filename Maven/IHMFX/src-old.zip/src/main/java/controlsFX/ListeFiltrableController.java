package controlsFX;


import general.ObjetCSA;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

import java.io.IOException;
import java.net.URL;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ResourceBundle;
import java.util.TreeSet;

public class ListeFiltrableController extends AnchorPane implements Initializable {

    private static final int SEUIL_GRANDE_LISTE = 200;
    private static final int MIN_CARACTERES_FILTRE = 1;
    @FXML
    public TextField tfFiltre;
    @FXML
    public ListView<Object> liste;
    @FXML
    public AnchorPane ListeFiltrable;
    @FXML
    public HBox ligneFiltre;
    private ArrayList<Object> listeOriginale = new ArrayList<>();
    private MaitreFX maitre;
    private Object selection;

    public ListeFiltrableController() {
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/fxml/ListeFiltrable.fxml"));

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        tfFiltre.setOnKeyReleased(this::action_filtrer);
        liste.setOnMouseReleased(this::action_clic_liste);
        liste.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        if (listeOriginale.size() > SEUIL_GRANDE_LISTE) {
            tfFiltre.setPromptText("Min. " + MIN_CARACTERES_FILTRE + " caractères");
        }
    }

    public void setMaitre(MaitreFX fx) {
        maitre = fx;
    }

    @FXML
    public void action_vider_textField(ActionEvent action) {
        tfFiltre.setText("");
        action_filtrer(null);
        selection = null;
    }

    public void setVisibiliteFiltre(boolean visible) {
        tfFiltre.setVisible(visible);
    }

    public void activer_ligneFiltre(boolean b) {
        ligneFiltre.setVisible(b);
        ligneFiltre.setPrefHeight(b ? 35 : 0);
    }

    public void removeSelected() {
        Collection selections = liste.getSelectionModel().getSelectedItems();
        if (selections.isEmpty()) {
            System.out.println("** ListeFiltrable reçoit un ordre de supprimer des lignes alors que rien n'est" +
                    " sélectionné. Ignoré !");
            return;
        }
        Platform.runLater(() -> {
            liste.getItems().removeAll(selections);
        });
    }

    public boolean contientDeja(Object nouveau) {
        if (listeOriginale.contains(nouveau)) {
            return true;
        }
        if (nouveau instanceof ObjetCSA) {
            ObjetCSA intrus = (ObjetCSA) nouveau;
            for (Object elt : listeOriginale) {
                if (elt instanceof ObjetCSA) {
                    if (((ObjetCSA) elt).getType().equals(intrus.getType()) &&
                            ((ObjetCSA) elt).getId() == intrus.getId()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @FXML
    public void action_filtrer(KeyEvent keyEvent) {
        if (!tfFiltre.getText().isEmpty()) {
            String filtre = Normalizer.normalize(tfFiltre.getText().trim().toUpperCase(),
                    Normalizer.Form.NFD).replaceAll("[\u0300-\u036F]",
                    "");
            TreeSet<Object> inclus = new TreeSet<>();


            listeOriginale.forEach((elt) -> {
                String selectionString;

                selectionString = Normalizer.normalize(elt.toString().trim().toUpperCase(),
                        Normalizer.Form.NFD).replaceAll("[\u0300-\u036F]",
                        "");

                if (selectionString.startsWith(filtre)) {
                    inclus.add(elt);
                }
            });
            Platform.runLater(() -> {
                liste.getItems().setAll(inclus);
                if (selection != null) {
                    if (selection instanceof ObjetCSA) {
                        liste.getSelectionModel().select(selection);
                    } else {
                        if (liste.getItems().contains(selection)) {
                            liste.getSelectionModel().select(selection);
                        } else {
                            clearSelection();
                        }
                    }
                } else {
                    clearSelection();
                }
            });
        } else {
            Platform.runLater(() -> {
                liste.getItems().clear();
                liste.getItems().addAll(listeOriginale);
            });
        }

    }

    private void clearSelection() {
        Platform.runLater(() -> {
            if (!liste.getItems().isEmpty()) {
                liste.getSelectionModel().clearAndSelect(-1);
                liste.refresh();
            }

            selection = null;
        });
    }

    @FXML
    public void action_clic_liste(MouseEvent mouseEvent) {
        selection = liste.getSelectionModel().getSelectedItem();
        if (maitre != null) {
            if (selection instanceof ObjetCSA) {
                maitre.charger_donnees_vers_enfant((ObjetCSA) selection);
                return;
            }
            maitre.affiche_console("ListeFiltrableController/action_clic_liste : " +
                    "la sélection n'est pas un hashObjet. Action igorée vers mon maitreFX");
            return;
        }
        System.err.println("La liste filtrable ne trouve pas d'éditeur. Impossible de charger les données !");
    }

    public void chargerListe(ArrayList<Object> l) {
        listeOriginale.clear();
        listeOriginale.addAll(l);
        action_filtrer(null);
    }

    public void addElement(Object x) {
        listeOriginale.add(x);
        action_filtrer(null);
    }

    public ArrayList<Object> getListeComplete() {
        return new ArrayList<>(listeOriginale);
    }

    public ArrayList<Object> getListeAffichee() {
        ObservableList<Object> listeInterne = liste.getItems();
        return new ArrayList<>(listeInterne);
    }

    public String getTexteFiltre() {
        return tfFiltre.getText();
    }

    public void setTexteFiltre(String s) {
        tfFiltre.setText(s);
    }

    public ObservableList<Object> getElementsSelectionnes() {
        return liste.getSelectionModel().getSelectedItems();
    }

    public TextField getTfFiltre() {
        return tfFiltre;
    }

    public ListView<Object> getListe() {
        return liste;
    }

}
