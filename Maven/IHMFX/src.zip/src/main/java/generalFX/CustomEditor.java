package generalFX;

import controlsFX.EditorPaneController;
import general.ObjetCSA;
import javafx.scene.layout.BorderPane;

import java.util.ArrayList;
import java.util.function.Consumer;

/**
 * CustomEditor - Éditeur personnalisé pour formulaires d'édition d'objets.
 * <p>
 * C'est un BorderPane qui implémente des méthodes comme :
 * charger_donnees, setConteneur(EditorPane), enregistrer et effacer_champs.
 * <p>
 * Le CustomEditor a accès à son EditorPaneController parent via getEditorPane(),
 * ce qui lui permet d'accéder aux handlers et services configurés sur le parent.
 */
public abstract class CustomEditor extends BorderPane {

    private EditorPaneController editorPane;
    private Consumer<ObjetCSA> onSaved;

    /**
     * Retourne l'EditorPaneController parent.
     *
     * @return l'EditorPane parent
     * @throws IllegalStateException si l'EditorPane n'a pas été initialisé
     */
    public EditorPaneController getEditorPane() {
        if (editorPane == null) {
            throw new IllegalStateException(
                    "CustomEditor non initialisé : l'EditorPane parent n'a pas été défini. " +
                            "Ceci devrait être fait automatiquement par EditorPaneController.setMaitre() ou setCustomEditor()."
            );
        }
        return editorPane;
    }

    /**
     * Définit l'EditorPaneController parent.
     * Appelé automatiquement par EditorPaneController lors de l'initialisation.
     *
     * @param editorPane l'EditorPane parent
     */
    public void setEditorPane(EditorPaneController editorPane) {
        this.editorPane = editorPane;
    }


    public void setOnSaved(Consumer<ObjetCSA> c) {
        this.onSaved = c;
    }

    protected void notifySaved(ObjetCSA o) {
        if (this.onSaved != null) {
            this.onSaved.accept(o);
        }
    }

    public abstract void charger_donnees(ObjetCSA objetDi);

    /**
     * Permet de remplir l'objetihm par les données qui se trouvent
     * actuellement dans les champs de données
     * Ne doit pas communiquer avec la BD !!!
     *
     * @return l'objetihm qui contiendra les informations des champs; null si échec !
     */
    public abstract ObjetCSA aspirer_donnees();

    public abstract void nettoyer_champs();

    /**
     * Ordonne au custumEditor de demander un rafraichissement de toutes ses listes
     */
    public abstract void rafraichir_listes();

    /**
     * Permet de rafraichir les liste du type fourni par la liste fournie
     *
     * @param objets c'est la liste qui devrait écraser la liste correspondante dans un des Composants
     * @param type   c'est le nom de table dans la BD du type de données qui est rafraichi
     */
    public abstract void rafraichir_liste(ArrayList<?> objets, String type);

}
