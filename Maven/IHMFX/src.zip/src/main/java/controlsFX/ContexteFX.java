package controlsFX;

import general.ObjetCSA;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Regroupe tous les handlers fonctionnels utilisés par les composants IHMFX
 * ({@link ListTableBDController}, {@link EditorPaneController}, {@link ComboEditableController}).
 * <p>
 * Permet de configurer une hiérarchie de composants imbriqués en une seule ligne
 * plutôt que d'appeler plusieurs {@code setXxxHandler()} à chaque niveau.
 * Le contexte se propage automatiquement vers les enfants lors de l'ouverture
 * d'un éditeur ou d'une liste.
 * <p>
 * <b>Exemple d'utilisation :</b>
 * <pre>{@code
 * ContexteFX ctx = new ContexteFX()
 *     .withSaveHandler((obj, callback) -> service.save(obj, callback))
 *     .withDeleteHandler((obj, callback) -> service.delete(obj, callback))
 *     .withRefreshListHandler(this::rechargerListe)
 *     .withTypeResolver(type -> ObjetFactory.create(type))
 *     .withMessageHandler(statusBar::setText);
 *
 * listTable.setContexte(ctx);
 * }</pre>
 * <p>
 * <b>Handlers propagés automatiquement :</b>
 * <ul>
 *   <li>{@code saveHandler} — enregistrement en BD (asynchrone)</li>
 *   <li>{@code deleteHandler} — suppression en BD (asynchrone)</li>
 *   <li>{@code refreshDetailsHandler} — chargement des détails d'un objet</li>
 *   <li>{@code refreshListHandler} — rafraîchissement de la liste principale</li>
 *   <li>{@code typeResolver} — résolution de type par nom de table</li>
 *   <li>{@code messageHandler} — affichage de messages utilisateur</li>
 *   <li>{@code consoleHandler} — affichage de messages console</li>
 *   <li>{@code userActionHandler} — notification d'actions utilisateur</li>
 * </ul>
 * <p>
 * Note : {@code parentNotifier} n'est pas dans le contexte car il est spécifique
 * à chaque niveau de la hiérarchie (chaque composant génère sa propre notification).
 */
public class ContexteFX {

    private BiConsumer<ObjetCSA, Consumer<List<Object>>> saveHandler;
    private BiConsumer<ObjetCSA, Consumer<List<Object>>> deleteHandler;
    private BiConsumer<ObjetCSA, Consumer<ObjetCSA>> refreshDetailsHandler;
    private Runnable refreshListHandler;
    private Function<String, ObjetCSA> typeResolver;
    private Consumer<String> messageHandler;
    private Consumer<String> consoleHandler;
    private BiConsumer<Object, String> userActionHandler;

    // -------------------------------------------------------------------------
    // Fluent setters (withXxx)
    // -------------------------------------------------------------------------

    /**
     * Handler d'enregistrement asynchrone vers la BD.
     * Le callback doit être appelé avec une liste dont le premier élément est un entier positif en cas de succès.
     */
    public ContexteFX withSaveHandler(BiConsumer<ObjetCSA, Consumer<List<Object>>> handler) {
        this.saveHandler = handler;
        return this;
    }

    /**
     * Handler de suppression asynchrone vers la BD.
     */
    public ContexteFX withDeleteHandler(BiConsumer<ObjetCSA, Consumer<List<Object>>> handler) {
        this.deleteHandler = handler;
        return this;
    }

    /**
     * Handler de chargement des détails d'un objet (pour la modification).
     */
    public ContexteFX withRefreshDetailsHandler(BiConsumer<ObjetCSA, Consumer<ObjetCSA>> handler) {
        this.refreshDetailsHandler = handler;
        return this;
    }

    /**
     * Handler de rafraîchissement de la liste principale.
     */
    public ContexteFX withRefreshListHandler(Runnable handler) {
        this.refreshListHandler = handler;
        return this;
    }

    /**
     * Résolveur de type : à partir d'un nom de table, retourne une instance de l'ObjetCSA correspondant.
     */
    public ContexteFX withTypeResolver(Function<String, ObjetCSA> resolver) {
        this.typeResolver = resolver;
        return this;
    }

    /**
     * Handler d'affichage de messages utilisateur (status bar, label, etc.).
     */
    public ContexteFX withMessageHandler(Consumer<String> handler) {
        this.messageHandler = handler;
        return this;
    }

    /**
     * Handler d'affichage de messages console/debug.
     */
    public ContexteFX withConsoleHandler(Consumer<String> handler) {
        this.consoleHandler = handler;
        return this;
    }

    /**
     * Handler de notification d'actions utilisateur (sélection, double-clic, etc.).
     */
    public ContexteFX withUserActionHandler(BiConsumer<Object, String> handler) {
        this.userActionHandler = handler;
        return this;
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public BiConsumer<ObjetCSA, Consumer<List<Object>>> getSaveHandler() {
        return saveHandler;
    }

    public BiConsumer<ObjetCSA, Consumer<List<Object>>> getDeleteHandler() {
        return deleteHandler;
    }

    public BiConsumer<ObjetCSA, Consumer<ObjetCSA>> getRefreshDetailsHandler() {
        return refreshDetailsHandler;
    }

    public Runnable getRefreshListHandler() {
        return refreshListHandler;
    }

    public Function<String, ObjetCSA> getTypeResolver() {
        return typeResolver;
    }

    public Consumer<String> getMessageHandler() {
        return messageHandler;
    }

    public Consumer<String> getConsoleHandler() {
        return consoleHandler;
    }

    public BiConsumer<Object, String> getUserActionHandler() {
        return userActionHandler;
    }
}

